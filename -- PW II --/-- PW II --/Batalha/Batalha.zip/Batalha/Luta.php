﻿<html>
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Seleção de Personagens</title>
   <style>
      body {
         background-image: url('back.jpg');
         background-size: cover;
         background-position: center;
         color: white;
         font-family: 'Arial', sans-serif;
         margin: 0;
         padding: 0;
         height: 100vh;
      }
      .container {
         max-width: 1200px;
         margin: 0 auto;
         padding: 50px 0;
         text-align: center;
      }
      h1 {
         font-size: 40px;
         margin-bottom: 30px;
      }
      .table-container {
         display: flex;
         justify-content: space-between;
         gap: 20px;
      }
      .column {
         width: 23%;
         text-align: center;
      }
      .personagem {
         background-color: rgba(0, 0, 0, 0.7);
         border-radius: 15px;
         padding: 20px;
         height: 350px;
         width: 100%;
         box-sizing: border-box;
      }
      .personagem img {
         height: 200px;
         width: 100%;
         border-radius: 15px;
         border: 3px solid #ccc;
      }
      .personagem h2 {
         font-size: 22px;
         margin-top: 15px;
         margin-bottom: 10px;
      }
      .personagem input[type="radio"] {
         margin-top: 10px;
      }
      .center {
         text-align: center;
         margin-top: 40px;
      }
      input[type="submit"] {
         background-color: #4CAF50;
         color: white;
         padding: 15px 32px;
         font-size: 18px;
         border: none;
         border-radius: 10px;
      }
   </style>
</head>
<body>
   <div class="container">
      <form method="POST" action="Batalha.php">
         <h1>Escolha seus Personagens para a Batalha!</h1>
         <div class="table-container">
            <div class="column">
               <div class="personagem">
                  <img src="ryu.jpg" alt="Ryu">
                  <h2>RYU</h2>
                  <input type="radio" name="Time1" value="Ryu">
               </div>
            </div>
            <div class="column">
               <div class="personagem">
                  <img src="guile.jpg" alt="Guile">
                  <h2>GUILE</h2>
                  <input type="radio" name="Time1" value="Guile">
               </div>
            </div>
            <div class="column">
               <div class="personagem">
                  <img src="ken.jpg" alt="Ken">
                  <h2>KEN</h2>
                  <input type="radio" name="Time1" value="Ken">
               </div>
            </div>
            <div class="column">
               <div class="personagem">
                  <img src="chunli.jpg" alt="Chun-Li">
                  <h2>CHUN-LI</h2>
                  <input type="radio" name="Time1" value="Chun-Li">
               </div>
            </div>
         </div>

         <div class="center">
            <h1>VS</h1>
         </div>

         <div class="table-container">
            <div class="column">
               <div class="personagem">
                  <img src="sagat.jpg" alt="Sagat">
                  <h2>SAGAT</h2>
                  <input type="radio" name="time2" value="Sagat">
               </div>
            </div>
            <div class="column">
               <div class="personagem">
                  <img src="blanka.jpg" alt="Blanka">
                  <h2>BLANKA</h2>
                  <input type="radio" name="time2" value="Blanka">
               </div>
            </div>
            <div class="column">
               <div class="personagem">
                  <img src="mbison.jpg" alt="M. Bison">
                  <h2>M. BISON</h2>
                  <input type="radio" name="time2" value="Bison">
               </div>
            </div>
            <div class="column">
               <div class="personagem">
                  <img src="Dhalsim.jpg" alt="Dhalsim">
                  <h2>DHALSIM</h2>
                  <input type="radio" name="time2" value="Dhalsim">
               </div>
            </div>
         </div>

         <div class="center" style="margin-top: 30px;">
            <input type="submit" value="Jogar">
         </div>
      </form>
   </div>
</body>
</html>
