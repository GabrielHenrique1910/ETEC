create database bd_MinhaEmpresa;

use bd_MinhaEmpresa;

create table tb_login (
	log_usuario varchar(8) primary key,
    log_senha varchar(8) not null,
    log_nome varchar(30) not null,
    log_ult_atualizacao timestamp not null
);
    
insert into tb_login (log_usuario, log_senha, log_nome, log_ult_atualizacao)
values  ('gabs1234', 'gabs@123', 'Gabs H', current_timestamp);