﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_MinhaLoja
{
    public partial class TelaSplash : Form
    {
        public TelaSplash()
        {
            InitializeComponent();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (progressBar.Value < 100){
                progressBar.Value = progressBar.Value + 4;
            }
            else {
                timer.Enabled = false;
                this.Visible = false;

                TelaLogin objTelaLogin = new TelaLogin();
                objTelaLogin.Show();
            }
        }
    }
}
