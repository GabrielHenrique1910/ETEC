﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace prj_MinhaLoja
{
    public partial class TelaLogin : Form
    {
        // Variáveis de controle de Conexão
        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public TelaLogin()
        {
            InitializeComponent();

            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa;User=root");
        }

        private void btn_Cadastre_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            frmCadNovoUsuario objTelaCadastro = new frmCadNovoUsuario();
            objTelaCadastro.Show();
        }

        private void TelaLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Confirma a saída da aplicação ?",
                "Mensagem", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)

                e.Cancel = false;
            else
                e.Cancel = true;
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "SELECT log_Senha FROM tb_login WHERE log_usuario = @parUsuario";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parUsuario", txtUsuario.Text);
                conexao.Open();
                comando.ExecuteScalar();
            }
            catch (MySqlException Erro)
            {
                MessageBox.Show("Erro -->" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                if (comando.ExecuteScalar() == null)
                {
                    MessageBox.Show("Usuário não encontrado!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    conexao.Close();
                    comando = null;
                }
                else 
                {
                    if (Convert.ToString(comando.ExecuteScalar()) != txtSenha.Text)
                    {
                        MessageBox.Show("Senha Inválida!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtSenha.Focus();
                        conexao.Close();
                        comando = null;
                    }
                    else 
                    {
                        this.Visible = false;
                        conexao.Close();
                        comando = null;

                        FrmPrincipal objFPrinc = new FrmPrincipal();
                        objFPrinc.ShowDialog();
                    }
                }
            }
        }
    }
}