﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; // <-- Inserir

namespace prj_MinhaLoja
{
    public partial class frmCadNovoUsuario : Form
    {
        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public frmCadNovoUsuario()
        {
            InitializeComponent();

            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa;User=root");
        }

        private void frmCadNovoUsuario_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNomeUsuario.ReadOnly = true;
            txtSenha.ReadOnly = true;
            btnCadastrar.Enabled = false;

            txtNomeUsuario.Text = "";
            txtSenha.Text = "";
            txtUsuario.Text = "";
            toolStripStatuslblMSG.Text = "Informe o Usuário <Enter>";
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            TelaLogin objTelaLogin = new TelaLogin();
            objTelaLogin.Show();
        }

        private void txtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter){
                try
                {
                    strSQL = "SELECT * FROM tb_login WHERE log_usuario = @parUsuario";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parUsuario", txtUsuario.Text);
                    conexao.Open();
                    dr = comando.ExecuteReader();
                }
                catch (MySqlException Erro)
                {
                    MessageBox.Show("Erro -->" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally
                {
                    if (!dr.HasRows) {
                        txtNomeUsuario.ReadOnly = false;
                        txtSenha.ReadOnly = false;
                        btnCadastrar.Enabled = true;
                        txtNomeUsuario.Clear();
                        txtSenha.Clear();
                        txtNomeUsuario.Focus();

                        toolStripStatuslblMSG.Text = "Digite o Nome do Usuário!";
                    }
                    else {
                        dr.Read();
                        txtNomeUsuario.Text = Convert.ToString(dr["log_nome"]);
                        txtSenha.Text = Convert.ToString(dr["log_senha"]);

                        toolStripStatuslblMSG.Text = "Usuário já cadastrado!!";
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtNomeUsuario.Text == "")
            {
                toolStripStatuslblMSG.Text = "Campo Nome do Usuário é Obrigatório!";
                txtNomeUsuario.Focus();
                return;
            }
            if (txtSenha.Text == "")
            {
                toolStripStatuslblMSG.Text = "Campo Senha é Obrigatório!";
                txtSenha.Focus();
                return;
            }

            try
            {
                strSQL = "INSERT INTO tb_login(log_usuario,log_senha,log_nome,log_ult_atualizacao) values (@parUsuario,@parSenha,@parNomeUsuario,CURRENT_TIMESTAMP)";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parUsuario", txtUsuario.Text);
                comando.Parameters.AddWithValue("@parSenha", txtSenha.Text);
                comando.Parameters.AddWithValue("@parNomeUsuario", txtNomeUsuario.Text);
                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (MySqlException Erro)
            {
                MessageBox.Show("Erro -->" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                toolStripStatuslblMSG.Text = "Cadastro efetuado com sucesso!";
                conexao.Close();
                comando = null;
            }
        }
    }
}
